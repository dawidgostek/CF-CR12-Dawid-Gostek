<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package cr12_DawidGostek_traveler
 */

get_header();
?>
<div class="container-fluid">
	<div class="row">
	
	<main id="primary" class="site-main col-12 col-lg-9 pt-5 bg-light">
		<div class="container">
			

		<?php if ( have_posts() ) : ?>

			<header class="page-header">
				<h1 class="page-title">
					<?php
					/* translators: %s: search query. */
					printf( esc_html__( 'Search Results for: %s', 'cr12_dawidgostek_traveler' ), '<span>' . get_search_query() . '</span>' );
					?>
				</h1>
			</header><!-- .page-header -->
			<div class="row">
			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();?>
				<div class="col-md-6 mb-4">
					<div class="card h-100">
						<?php cr12_dawidgostek_traveler_post_thumbnail(); ?>
						<div class="card-body">
							<h3 class="card-title"><?php the_title(); ?></h3>
							<p class="card-text"><?php the_excerpt(); ?></p>
							<p class="card-text"><?php the_time('F j, Y g:i a'); ?> <?php the_author(); ?></p>
							<a href="<?php the_permalink(); ?>" class="btn btn-secondary">Go to Post</a>
							
						</div>
					</div>
				</div>

				<?php

			endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
		</div>
	</div>
	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
